# ImageReader

## Usage

Use command below to execute this program:

```bash
chmod +x src/run.sh
src/run.sh
```

## Test

Use command below to execute test program:

```bash
chmod +x ./test.sh
src/test.sh
```
